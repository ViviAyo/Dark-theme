const container = document.querySelector('.container');
const registerBtn = document.querySelector('.register-btn');
const loginnBtn = document.querySelector('.login-btn');

registerBtn.addEventListener('click', () => {
  container.classList.add('active');
});

loginnBtn.addEventListener('click', () => {
  container.classList.remove('active');
});